
import { create } from 'zustand';
import { UserProfile } from '@/types/auth';

interface AuthStore {
  user: UserProfile | null;
  setUser: (user: UserProfile | null) => void;
  logout: () => void;
  updateBalance: (amount: number) => void;
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  setUser: (user) => set({ user }),
  logout: () => set({ user: null }),
  updateBalance: (amount) => set((state) => ({
    user: state.user ? { ...state.user, balance: state.user.balance + amount } : null
  })),
}));
